# Prompt para Claude Code — Correção Visual + Uso do Pack de Imagens

Quero que você faça uma refatoração visual do projeto atual do TG **sem reescrever tudo do zero**.

O foco desta alteração é corrigir a visualização 2D/3D, deixar a arquitetura espacial muito mais clara para banca e integrar um pack de imagens/assets visuais para dar aparência profissional, espacial e técnica.

---

## 1. Problema atual

A visualização atual está confusa:

- o grafo 2D está espalhado demais;
- os nós estão pequenos;
- a hierarquia não está clara;
- as relações estão difíceis de entender;
- o MiniMap está bugado/cortado/desproporcional;
- a cena 3D parece um aglomerado de objetos e labels;
- os labels 3D se sobrepõem;
- o usuário não entende rapidamente a cadeia de engenharia de sistemas.

---

## 2. Objetivo visual

A aplicação precisa parecer:

```txt
mission control + MBSE visual + arquitetura de sistemas espaciais + visualizador técnico 2D/3D
```

A banca deve entender rapidamente:

```txt
Missão → Objetivos → Requisitos → Funções → Segmentos → Sistemas/Subsistemas → Componentes → Interfaces → Budgets/Riscos → Verificação
```

A prioridade é:

```txt
clareza da arquitetura > rastreabilidade > relações visíveis > estética espacial > efeitos visuais
```

Não quero um grafo genérico nem uma cena 3D decorativa.  
Quero uma visualização com lógica de engenharia de sistemas.

---

## 3. Pack de imagens fornecido

Copie o conteúdo do pack para:

```txt
src/assets/images/
```

Sugestão de organização:

```txt
src/assets/images/
  backgrounds/
  overlays/
  textures/
  ui/
  references/
```

### Arquivos principais do pack

#### Backgrounds

```txt
backgrounds/01_bg_space_starfield_deep.png
backgrounds/02_bg_earth_horizon_dark.png
backgrounds/03_bg_blue_nebula_subtle.png
backgrounds/04_bg_milkyway_dark_subtle.png
backgrounds/05_bg_ground_station_rf_link.png
```

Use como:
- fundo principal da aplicação;
- fundo do modo 3D;
- fundo escuro de painéis;
- backdrop da tela inicial;
- imagem de apoio para o segmento solo.

#### Overlays transparentes

```txt
overlays/01_overlay_orbital_grid_transparent.png
overlays/02_overlay_blueprint_grid_transparent.png
overlays/03_overlay_hud_radar_transparent.png
overlays/04_overlay_scanlines_and_center_glow.png
```

Use como:
- camada visual por cima dos backgrounds;
- fundo sutil do React Flow;
- HUD técnico nos painéis;
- grid orbital no modo 3D;
- efeito discreto de mission control.

#### Texturas

```txt
textures/01_texture_solar_panel_cells.png
textures/02_texture_dark_metal_panel.png
textures/03_texture_carbon_fiber_dark.png
textures/04_texture_circuit_board_blue.png
textures/05_texture_radiator_louver.png
```

Use em materiais 3D:
- painéis solares;
- bus/satélite;
- caixas eletrônicas;
- OBC/OBDH;
- radiadores térmicos;
- componentes do spacecraft.

#### UI e referências

```txt
ui/01_relation_legend_strip.png
ui/02_traceability_chain_card.png
ui/03_minimap_reference_fixed.png
ui/04_status_budget_cards_reference.png

references/01_reference_2d_swimlanes_traceability.png
references/02_reference_3d_scene_architecture.png
references/AI_style_board_01_generated.png
references/AI_style_board_02_generated.png
```

Use como:
- referência de estilo;
- guia visual para layout;
- inspiração para painéis;
- referência para legenda;
- referência para rastreabilidade;
- não necessariamente como imagem final direta.

---

## 4. Regras para usar as imagens

### 4.1 Não sacrificar legibilidade

Sempre aplicar overlay escuro sobre imagens de fundo:

```css
background:
  linear-gradient(180deg, rgba(2,6,23,0.86), rgba(2,6,23,0.94)),
  url("/src/assets/images/backgrounds/02_bg_earth_horizon_dark.png");
```

O texto principal deve continuar legível.

### 4.2 Não usar imagens como decoração aleatória

Cada imagem deve ter função:

```txt
background espacial → contexto da missão
grid orbital → ambiente técnico
textura solar → painéis solares 3D
textura metálica → bus/estrutura
textura circuito → OBC/OBDH/software
legend strip → legenda de relações
traceability card → painel de rastreabilidade
```

### 4.3 Não depender de URL externa

Nada deve carregar de internet em runtime.  
Tudo deve ser local em `src/assets/images/`.

### 4.4 Não usar os style boards como logotipo ou branding oficial

As imagens são referências visuais geradas para o TG.  
Não representar como produto oficial da NASA.

---

## 5. Correção obrigatória da visualização 2D

### 5.1 Trocar grafo solto por layout de engenharia de sistemas

O React Flow deve ser organizado por faixas ou colunas:

```txt
MISSÃO
OBJETIVOS
REQUISITOS
FUNÇÕES
SEGMENTOS / SISTEMAS
SUBSISTEMAS
COMPONENTES
VERIFICAÇÃO / BUDGETS / RISCOS
```

Cada faixa deve ter:
- título visível;
- fundo sutil;
- separação visual;
- espaçamento confortável;
- nós maiores;
- arestas menos caóticas.

### 5.2 Usar layout automático hierárquico

Implementar ou corrigir layout com:

```txt
dagre
```

ou

```txt
elkjs
```

Critérios:
- sem sobreposição de nós;
- menos cruzamento de arestas;
- espaçamento consistente;
- `fitView` funcionando;
- zoom inicial adequado.

### 5.3 Criar modos de visualização 2D

Não mostrar tudo ao mesmo tempo.

Criar modos:

```txt
Hierarquia
Rastreabilidade
Interfaces
Funcional
Verificação
```

#### Hierarquia
Mostrar principalmente:
- contains;
- parent-child;
- segmento espacial;
- segmento solo;
- lançador;
- spacecraft;
- payload;
- bus;
- subsistemas;
- componentes.

#### Rastreabilidade
Mostrar:

```txt
Missão → Objetivo → Requisito → Função → Componente → Verificação
```

#### Interfaces
Mostrar:
- power;
- data;
- command;
- RF;
- mechanical;
- thermal;
- control.

#### Funcional
Mostrar:
- funções;
- componentes alocados;
- subsistemas responsáveis.

#### Verificação
Mostrar:
- requisitos;
- métodos de verificação;
- itens verificados;
- status.

---

## 6. Correção obrigatória do MiniMap

O MiniMap atual deve ser corrigido.

Requisitos:

- não pode aparecer cortado;
- não pode ficar gigante ou minúsculo;
- deve refletir corretamente pan/zoom;
- deve ficar no canto inferior direito;
- deve ter tamanho fixo controlado;
- deve respeitar painéis laterais e inferiores;
- deve ter cores por tipo de nó;
- deve ter borda e fundo coerentes com o tema.

CSS sugerido:

```css
.react-flow__minimap {
  width: 220px;
  height: 150px;
  right: 18px;
  bottom: 18px;
  border-radius: 14px;
  overflow: hidden;
  background: rgba(2, 6, 23, 0.92);
  border: 1px solid rgba(56, 189, 248, 0.35);
  box-shadow: 0 12px 36px rgba(0,0,0,0.45);
}
```

O container do React Flow deve ter altura/largura explícitas:

```css
.flow-shell,
.react-flow-wrapper {
  width: 100%;
  height: 100%;
  min-height: 0;
  overflow: hidden;
}
```

Usar `fitView` com padding controlado:

```tsx
<ReactFlow
  fitView
  fitViewOptions={{ padding: 0.18, includeHiddenNodes: false }}
  minZoom={0.15}
  maxZoom={1.6}
/>
```

Se o MiniMap nativo continuar instável, corrigir sizing/overflow antes de adicionar efeitos visuais.

---

## 7. Correção obrigatória da visualização 3D

A cena 3D não deve ser uma nuvem de objetos.

Organizar assim:

```txt
Centro: Spacecraft / Bus
Laterais: painéis solares
Frente: payload
Topo/lateral: antena TT&C
Ao redor: subsistemas principais
Região separada: Ground Segment
Região separada: Launch Segment
Linhas: interfaces significativas
```

### 7.1 Organização dos subsistemas em 3D

Distribuir ao redor do satélite:

```txt
Payload
EPS
OBC/OBDH
TT&C
ADCS/AOCS
Thermal
Propulsion
Structure
Software
```

Não colocar todos no mesmo ponto.

### 7.2 Labels 3D

Não mostrar todos os labels ao mesmo tempo.

Regras:
- labels permanentes só para entidades principais;
- labels de componentes aparecem em hover ou seleção;
- evitar sobreposição;
- usar tamanho menor;
- usar fundo escuro translúcido;
- esconder labels distantes ou irrelevantes.

### 7.3 Texturas 3D

Usar as texturas do pack:

- `01_texture_solar_panel_cells.png` nos painéis solares;
- `02_texture_dark_metal_panel.png` no bus;
- `04_texture_circuit_board_blue.png` em OBC/OBDH;
- `05_texture_radiator_louver.png` nos radiadores;
- `03_texture_carbon_fiber_dark.png` na estrutura.

Se texturas causarem problema de carregamento, manter material procedural como fallback.

### 7.4 Modos 3D

Criar modos simples:

```txt
Overview
Space Segment
Ground Segment
Interfaces
Selected Item
```

No modo Overview:
- mostrar só blocos principais;
- labels principais;
- poucas linhas.

No modo Interfaces:
- destacar relações;
- ocultar geometrias secundárias se necessário.

No modo Selected Item:
- reduzir opacidade do resto;
- destacar item;
- destacar relações conectadas.

---

## 8. Relações e rastreabilidade visual

Ao selecionar qualquer nó ou objeto 3D:

- destacar entidade selecionada;
- destacar vizinhos diretos;
- destacar caminho de rastreabilidade;
- reduzir opacidade do restante;
- mostrar no painel lateral a cadeia completa.

Cadeia esperada:

```txt
Missão → Objetivo → Requisito → Função → Componente → Verificação
```

Também mostrar relações de interface:

```txt
provides_power_to
sends_data_to
receives_command_from
communicates_with
mechanically_attached_to
thermally_coupled_to
controls
measures
actuates
```

As relações devem ter cor e estilo diferentes.

---

## 9. Painel lateral

Ao selecionar item, mostrar:

```txt
IDENTIFICAÇÃO
HIERARQUIA
RASTREABILIDADE
REQUISITOS
FUNÇÕES
INTERFACES
BUDGETS
RISCOS
VERIFICAÇÃO
METADATA
```

O painel deve ajudar a explicar a arquitetura, não apenas listar JSON.

---

## 10. Arquivos que provavelmente precisam ser alterados

Priorizar:

```txt
src/components/graph/*
src/components/scene3d/*
src/components/panels/*
src/store/*
src/styles/*
src/utils/layout/*
src/utils/traceability/*
```

Criar se necessário:

```txt
src/utils/layout/buildHierarchicalLayout.ts
src/utils/traceability/findTraceabilityPath.ts
src/utils/relations/relationStyles.ts
src/components/graph/SwimlaneBackground.tsx
src/components/graph/GraphModeToolbar.tsx
src/components/scene3d/SpacecraftAssembly.tsx
src/components/scene3d/GroundSegmentScene.tsx
src/components/scene3d/InterfaceLines3D.tsx
```

---

## 11. Critérios de aceite

A entrega só é aceitável se:

1. o grafo 2D estiver organizado por níveis de engenharia de sistemas;
2. a hierarquia estiver clara;
3. as relações estiverem legíveis;
4. a rastreabilidade estiver clara;
5. existirem modos/filtros para reduzir poluição visual;
6. os nós estiverem maiores e melhores;
7. o MiniMap estiver corrigido;
8. o MiniMap não estiver cortado;
9. a cena 3D estiver organizada por arquitetura espacial;
10. os labels 3D não estiverem sobrepostos;
11. 2D e 3D estiverem sincronizados por seleção;
12. o pack de imagens estiver integrado de forma útil;
13. a aplicação parecer apresentável para banca;
14. `npm run build` passar sem erros.

---

## 12. Orientação final

Não quero apenas “deixar bonito”.

Quero que a aplicação comunique visualmente a engenharia de sistemas do TG:

```txt
Missão → Objetivos → Requisitos → Funções → Sistema → Subsistemas → Componentes → Interfaces → Budgets → Riscos → Verificação
```

O resultado deve ser fácil de explicar, fácil de navegar e visualmente profissional.
