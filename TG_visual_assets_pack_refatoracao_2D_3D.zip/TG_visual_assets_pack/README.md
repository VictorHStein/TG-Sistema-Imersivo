# TG Visual Assets Pack

Pack de imagens e markdown para refatoração visual do MVP do TG.

Conteúdo:
- backgrounds espaciais;
- overlays transparentes;
- texturas para Three.js;
- referências de layout 2D/3D;
- elementos de UI;
- prompt em Markdown para Claude Code.

Use o arquivo:
docs/PROMPT_CLAUDE_CODE_REFATORACAO_VISUAL_COM_ASSETS.md
